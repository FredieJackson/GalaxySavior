package app.onedayofwar.Graphics;

/**
 * Created by Slava on 25.03.2015.
 */
public class Glyph
{
    int id;
    int x, y;
    int width, height;
    public Glyph(int id, int x, int y, int width, int height)
    {
        this.id = id;
        this.height = height;
        this.width = width;
        this.x = x;
        this.y = y;
    }
}
