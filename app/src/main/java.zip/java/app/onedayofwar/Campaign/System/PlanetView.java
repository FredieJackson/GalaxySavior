package app.onedayofwar.Campaign.System;

import android.graphics.Color;
import android.util.Log;
import android.view.MotionEvent;

import app.onedayofwar.Battle.BattleElements.BattlePlayer;
import app.onedayofwar.Battle.Mods.SingleBattle;
import app.onedayofwar.Campaign.Space.Planet;
import app.onedayofwar.Campaign.Space.Space;
import app.onedayofwar.Graphics.Assets;
import app.onedayofwar.Graphics.Graphics;
import app.onedayofwar.Graphics.ScreenView;
import app.onedayofwar.Graphics.Sprite;
import app.onedayofwar.System.GLView;
import app.onedayofwar.System.Vector2;
import app.onedayofwar.UI.Button;

/**
 * Created by Slava on 30.03.2015.
 */
public class PlanetView implements ScreenView
{
    private GLView glView;
    private Space space;
    private Planet planet;
    private Button attackBtn;
    private Button exitBtn;
    private Button buildInfo;
    private Vector2 touchPos;
    private Sprite gArmy;
    private boolean showBuildInfo;

    public PlanetView(GLView glView, Space space, Planet planet)
    {
        this.glView = glView;
        this.planet = planet;
        this.space = space;
    }

    @Override
    public void Initialize(Graphics graphics)
    {
        touchPos = new Vector2();
        showBuildInfo = false;
        gArmy = new Sprite(Assets.robotImage);
        gArmy.Scale((float)Assets.isoGridCoeff);
        ButtonsInitialize();
    }

    @Override
    public void Update(float eTime)
    {

    }

    @Override
    public void Draw(Graphics graphics)
    {
        if(planet.IsConquered())
        {
            if(showBuildInfo)
            {
                graphics.DrawText("Market: " + planet.getBuildings()[0] + "\nOil Drill: " + planet.getBuildings()[1] + "\nNano Steel Mines: " + planet.getBuildings()[2] + "\nFactory: " + planet.getBuildings()[3] + "\nWorkshop: " + planet.getBuildings()[4], Assets.arialFont, 0, 0, 0, Color.GREEN, 50);
            }
            else
            {
                graphics.DrawText("Credits: " + planet.credits + "\nOil: " + planet.oil + "\nNano Steel: " + planet.nanoSteel, Assets.arialFont, 0, 0, 0, Color.GREEN, 50);

                gArmy.setTexture(Assets.robotImage);
                gArmy.setPosition(gArmy.getWidth() / 2 + 30, 150 + gArmy.getHeight() / 2 + 10);
                graphics.DrawSprite(gArmy);
                graphics.DrawText("x" + planet.getGroundGuards()[0], Assets.arialFont, gArmy.matrix[12] + gArmy.getWidth() / 2, gArmy.matrix[13], 0, Color.GREEN, 30);
                gArmy.Move(0, gArmy.getHeight() / 2);

                gArmy.setTexture(Assets.ifvImage);
                gArmy.Move(gArmy.getWidth() / 2 + 30 - gArmy.matrix[12], 10 + gArmy.getHeight() / 2);
                graphics.DrawSprite(gArmy);
                graphics.DrawText("x" + planet.getGroundGuards()[1], Assets.arialFont, gArmy.matrix[12] + gArmy.getWidth() / 2, gArmy.matrix[13], 0, Color.GREEN, 30);
                gArmy.Move(0, gArmy.getHeight() / 2);

                gArmy.setTexture(Assets.engineerImage);
                gArmy.Move(gArmy.getWidth() / 2 + 30 - gArmy.matrix[12], 10 + gArmy.getHeight() / 2);
                graphics.DrawSprite(gArmy);
                graphics.DrawText("x" + planet.getGroundGuards()[2], Assets.arialFont, gArmy.matrix[12] + gArmy.getWidth() / 2, gArmy.matrix[13], 0, Color.GREEN, 30);
                gArmy.Move(0, gArmy.getHeight() / 2);

                gArmy.setTexture(Assets.tankImage);
                gArmy.Move(gArmy.getWidth() / 2 + 30 - gArmy.matrix[12], 10 + gArmy.getHeight() / 2);
                graphics.DrawSprite(gArmy);
                graphics.DrawText("x" + planet.getGroundGuards()[3], Assets.arialFont, gArmy.matrix[12] + gArmy.getWidth() / 2, gArmy.matrix[13], 0, Color.GREEN, 30);
                gArmy.Move(0, gArmy.getHeight() / 2);

                gArmy.setTexture(Assets.turretImage);
                gArmy.Move(gArmy.getWidth() / 2 + 30 - gArmy.matrix[12], 10 + gArmy.getHeight() / 2);
                graphics.DrawSprite(gArmy);
                graphics.DrawText("x" + planet.getGroundGuards()[4], Assets.arialFont, gArmy.matrix[12] + gArmy.getWidth() / 2, gArmy.matrix[13], 0, Color.GREEN, 30);
                gArmy.Move(0, gArmy.getHeight() / 2);

                gArmy.setTexture(Assets.sonderImage);
                gArmy.Move(gArmy.getWidth() / 2 + 30 - gArmy.matrix[12], 10 + gArmy.getHeight() / 2);
                graphics.DrawSprite(gArmy);
                graphics.DrawText("x" + planet.getGroundGuards()[5], Assets.arialFont, gArmy.matrix[12] + gArmy.getWidth() / 2, gArmy.matrix[13], 0, Color.GREEN, 30);
                gArmy.Move(0, gArmy.getHeight() / 2);
            }
        }
        ButtonsDraw(graphics);
    }

    @Override
    public void OnTouch(MotionEvent event)
    {
        touchPos.SetValue(event.getX(), event.getY());
        //Обновляем кнопки
        ButtonsUpdate();
        //Если было совершено нажатие на экран
        if(event.getAction() == MotionEvent.ACTION_DOWN)
        {
            //Пытаемся обработать нажатия кнопок
            CheckButtons();
        }
        //Если убрали палец с экрана
        else if(event.getAction() == MotionEvent.ACTION_UP)
        {
            //Сбрасываем состояние кнопок
            ButtonsReset();
        }
    }

    @Override
    public void Resume()
    {

    }

    /**
     * Обрабатывает нажатия на кнопки
     */
    public void CheckButtons()
    {
        if(attackBtn.IsClicked())
        {
            Log.i("BATTLE", "START");
            BattlePlayer.fieldSize = 15;
            BattlePlayer.unitCount = space.getPlayer().getArmy().clone();
            SingleBattle.difficulty = (byte)(Math.random()*10);
            glView.StartBattle(planet, 'c', Math.random() < 0.5);
        }
        else if(exitBtn.IsClicked())
        {
            if(showBuildInfo)
                showBuildInfo = false;
            else
                glView.goBack();
        }
        else if(buildInfo.IsClicked())
        {
            showBuildInfo = true;
        }
    }

    /**
     * Обновляет состояние кнопок
     */
    private void ButtonsUpdate()
    {
        if(planet.IsConquered())
        {
            buildInfo.Update(touchPos);
        }
        else
        {
            attackBtn.Update(touchPos);
        }
        exitBtn.Update(touchPos);
    }

    /**
     * Обнуляет состояние кнопок
     */
    private void ButtonsReset()
    {
        attackBtn.Reset();
        exitBtn.Reset();
        buildInfo.Reset();
    }

    /**
     * Отрисовывает кнопки
     * @param
     */
    private void ButtonsDraw(Graphics graphics)
    {
        if(planet.IsConquered())
        {
            buildInfo.Draw(graphics);
        }
        else
        {
            attackBtn.Draw(graphics);
        }
        exitBtn.Draw(graphics);
    }

    /**
     * Инициализирует кнопки
     */
    private void ButtonsInitialize()
    {
        attackBtn = new Button(Assets.btnFinishInstallation, 0, 0, false);
        attackBtn.Scale(Assets.btnCoeff);
        attackBtn.SetPosition(glView.getScreenWidth() - attackBtn.width/2 - 50, glView.getScreenHeight() - attackBtn.height/2 - 50);

        exitBtn = new Button(Assets.btnCancel, 0, 0, false);
        exitBtn.Scale(Assets.btnCoeff);
        exitBtn.SetPosition(attackBtn.getMatrix()[12], attackBtn.getMatrix()[13] - exitBtn.height - 10);

        buildInfo = new Button(Assets.btnTurn, 0, 0, false);
        buildInfo.Scale(Assets.btnCoeff);
        buildInfo.SetPosition(attackBtn.getMatrix()[12], exitBtn.getMatrix()[13] - buildInfo.height - 10);
    }
}
