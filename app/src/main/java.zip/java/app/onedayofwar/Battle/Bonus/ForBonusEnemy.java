package app.onedayofwar.Battle.Bonus;

import app.onedayofwar.System.Vector2;

/**
 * Created by Никита on 29.03.2015.
 */
public class ForBonusEnemy
{
    public static int[][] glareArr;
    public static Vector2 socket;
    public static boolean canISendResult;
    public static boolean canITakeResult;
    public static boolean pvoSend;
    public static boolean pvoGet;
    public static boolean reloadGet;
    public static int skill;
}
